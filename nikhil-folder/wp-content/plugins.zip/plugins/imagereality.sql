-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Host: 192.168.1.77
-- Generation Time: Oct 18, 2014 at 04:18 PM
-- Server version: 5.5.34
-- PHP Version: 5.4.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `imagereality`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE IF NOT EXISTS `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE IF NOT EXISTS `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2014-10-18 05:45:39', '2014-10-18 05:45:39', 'Hi, this is a comment.\nTo delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE IF NOT EXISTS `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE IF NOT EXISTS `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=162 ;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://192.168.1.77/imagereality', 'yes'),
(2, 'home', 'http://192.168.1.77/imagereality', 'yes'),
(3, 'blogname', 'imagereality', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '1', 'yes'),
(6, 'admin_email', 'poonam@amarinfotech.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '', 'yes'),
(29, 'gzipcompression', '0', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:7:{i:1;s:36:"contact-form-7/wp-contact-form-7.php";i:2;s:21:"customPosts/index.php";i:3;s:23:"page_category/index.php";i:4;s:23:"post-meta/post-meta.php";i:5;s:47:"useful-banner-manager/useful-banner-manager.php";i:6;s:24:"userManagement/index.php";i:7;s:33:"zm-ajax-login-register/plugin.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'advanced_edit', '0', 'yes'),
(37, 'comment_max_links', '2', 'yes'),
(38, 'gmt_offset', '0', 'yes'),
(39, 'default_email_category', '1', 'yes'),
(40, 'recently_edited', '', 'no'),
(41, 'template', 'New_property', 'yes'),
(42, 'stylesheet', 'New_property', 'yes'),
(43, 'comment_whitelist', '1', 'yes'),
(44, 'blacklist_keys', '', 'no'),
(45, 'comment_registration', '0', 'yes'),
(46, 'html_type', 'text/html', 'yes'),
(47, 'use_trackback', '0', 'yes'),
(48, 'default_role', 'subscriber', 'yes'),
(49, 'db_version', '29630', 'yes'),
(50, 'uploads_use_yearmonth_folders', '1', 'yes'),
(51, 'upload_path', '', 'yes'),
(52, 'blog_public', '1', 'yes'),
(53, 'default_link_category', '2', 'yes'),
(54, 'show_on_front', 'posts', 'yes'),
(55, 'tag_base', '', 'yes'),
(56, 'show_avatars', '1', 'yes'),
(57, 'avatar_rating', 'G', 'yes'),
(58, 'upload_url_path', '', 'yes'),
(59, 'thumbnail_size_w', '150', 'yes'),
(60, 'thumbnail_size_h', '150', 'yes'),
(61, 'thumbnail_crop', '1', 'yes'),
(62, 'medium_size_w', '300', 'yes'),
(63, 'medium_size_h', '300', 'yes'),
(64, 'avatar_default', 'mystery', 'yes'),
(65, 'large_size_w', '1024', 'yes'),
(66, 'large_size_h', '1024', 'yes'),
(67, 'image_default_link_type', 'file', 'yes'),
(68, 'image_default_size', '', 'yes'),
(69, 'image_default_align', '', 'yes'),
(70, 'close_comments_for_old_posts', '0', 'yes'),
(71, 'close_comments_days_old', '14', 'yes'),
(72, 'thread_comments', '1', 'yes'),
(73, 'thread_comments_depth', '5', 'yes'),
(74, 'page_comments', '0', 'yes'),
(75, 'comments_per_page', '50', 'yes'),
(76, 'default_comments_page', 'newest', 'yes'),
(77, 'comment_order', 'asc', 'yes'),
(78, 'sticky_posts', 'a:0:{}', 'yes'),
(79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_text', 'a:0:{}', 'yes'),
(81, 'widget_rss', 'a:0:{}', 'yes'),
(82, 'uninstall_plugins', 'a:2:{s:65:"featured-images-for-categories/featured-images-for-categories.php";s:45:"WPFeaturedImgCategories::wpfifc_remove_option";s:53:"category-featured-images/category-featured-images.php";a:2:{i:0;s:24:"category_featured_images";i:1;s:9:"uninstall";}}', 'no'),
(83, 'timezone_string', '', 'yes'),
(84, 'page_for_posts', '0', 'yes'),
(85, 'page_on_front', '0', 'yes'),
(86, 'default_post_format', '0', 'yes'),
(87, 'link_manager_enabled', '0', 'yes'),
(88, 'initial_db_version', '29630', 'yes'),
(89, 'wp_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:10:"individual";a:2:{s:4:"name";s:15:"Individual user";s:12:"capabilities";a:1:{s:4:"read";b:0;}}s:9:"developer";a:2:{s:4:"name";s:9:"Developer";s:12:"capabilities";a:1:{s:4:"read";b:0;}}}', 'yes'),
(90, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(91, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(92, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(93, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'sidebars_widgets', 'a:8:{s:19:"wp_inactive_widgets";a:0:{}s:8:"top_tabs";a:7:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:15:"wpfifc_widget-2";i:5;s:12:"categories-2";i:6;s:6:"meta-2";}s:11:"top_sidebar";a:1:{i:0;s:40:"useful-banner-manager-banners-rotation-2";}s:12:"left_sidebar";a:0:{}s:13:"right_sidebar";a:1:{i:0;s:40:"useful-banner-manager-banners-rotation-4";}s:14:"right_sidebar2";a:1:{i:0;s:40:"useful-banner-manager-banners-rotation-5";}s:14:"right_sidebar3";a:1:{i:0;s:40:"useful-banner-manager-banners-rotation-6";}s:13:"array_version";i:3;}', 'yes'),
(96, 'cron', 'a:7:{i:1413611142;a:1:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1413611143;a:2:{s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1413611151;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1413611667;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1413612243;a:1:{s:24:"post_meta_schedule_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1413660420;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}s:7:"version";i:2;}', 'yes'),
(97, '_transient_doing_cron', '1413641821.3726439476013183593750', 'yes'),
(98, '_transient_random_seed', '8d2a6b86509fdd27f9bc9b5a6bde8d76', 'yes'),
(99, '_site_transient_update_core', 'O:8:"stdClass":3:{s:7:"updates";a:0:{}s:15:"version_checked";s:3:"4.0";s:12:"last_checked";i:1413611151;}', 'yes'),
(100, '_site_transient_update_plugins', 'O:8:"stdClass":1:{s:12:"last_checked";i:1413627823;}', 'yes'),
(101, '_site_transient_timeout_theme_roots', '1413613374', 'yes'),
(102, '_site_transient_theme_roots', 'a:4:{s:12:"New_property";s:7:"/themes";s:14:"twentyfourteen";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";s:12:"twentytwelve";s:7:"/themes";}', 'yes'),
(103, '_site_transient_update_themes', 'O:8:"stdClass":1:{s:12:"last_checked";i:1413612387;}', 'yes'),
(104, 'can_compress_scripts', '1', 'yes'),
(105, '_transient_timeout_plugin_slugs', '1413714228', 'no'),
(106, '_transient_plugin_slugs', 'a:10:{i:0;s:19:"akismet/akismet.php";i:1;s:23:"page_category/index.php";i:2;s:36:"contact-form-7/wp-contact-form-7.php";i:3;s:21:"customPosts/index.php";i:4;s:9:"hello.php";i:5;s:53:"nextend-facebook-connect/nextend-facebook-connect.php";i:6;s:23:"post-meta/post-meta.php";i:7;s:47:"useful-banner-manager/useful-banner-manager.php";i:8;s:24:"userManagement/index.php";i:9;s:33:"zm-ajax-login-register/plugin.php";}', 'no'),
(107, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1413654379', 'no'),
(108, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><p><strong>RSS Error</strong>: WP HTTP Error: Failed connect to wordpress.org:8888; No route to host</p></div><div class="rss-widget"><p><strong>RSS Error</strong>: WP HTTP Error: Failed connect to planet.wordpress.org:8888; No route to host</p></div><div class="rss-widget"><ul></ul></div>', 'no'),
(113, 'recently_activated', 'a:2:{s:53:"category-featured-images/category-featured-images.php";i:1413627792;s:47:"post-tags-and-categories-for-pages/post-tag.php";i:1413626440;}', 'yes'),
(114, 'wpcf7', 'a:1:{s:7:"version";s:3:"3.9";}', 'yes'),
(115, 'pm_settings', 'a:1:{s:4:"file";a:2:{s:6:"allext";a:5:{s:4:"file";a:4:{i:0;s:3:"zip";i:1;s:3:"rar";i:2;s:2:"7z";i:3;s:3:"iso";}s:8:"document";a:3:{i:0;s:3:"pdf";i:1;s:3:"doc";i:2;s:3:"ppt";}s:5:"image";a:4:{i:0;s:3:"jpg";i:1;s:4:"jpeg";i:2;s:3:"png";i:3;s:3:"gif";}s:5:"audio";a:3:{i:0;s:3:"mp3";i:1;s:3:"wav";i:2;s:3:"wma";}s:5:"video";a:4:{i:0;s:3:"mp4";i:1;s:3:"flv";i:2;s:3:"avi";i:3;s:3:"wmv";}}s:13:"max_file_size";s:3:"200";}}', 'yes'),
(116, 'theme_mods_twentyfourteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1413612386;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(117, 'current_theme', '', 'yes'),
(118, 'theme_mods_New_property', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}}', 'yes'),
(119, 'theme_switched', '', 'yes'),
(120, 'useful_banner_manager_version', '1.5', 'yes'),
(121, 'ajax_login_register_plugin_notice_shown', 'true', 'yes'),
(122, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(123, 'ajax_login_register_advanced_usage_login', '.login', 'yes'),
(124, 'ajax_login_register_advanced_usage_register', '.Register', 'yes'),
(125, 'ajax_login_register_additional_styling', '', 'yes'),
(126, 'ajax_login_register_redirect', '?page_id=13', 'yes'),
(127, 'ajax_login_register_default_style', 'default', 'yes'),
(128, 'url', '', 'yes'),
(129, 'app_id', '', 'yes'),
(130, 'ajax_login_register_facebook', '', 'yes'),
(131, 'ajax_login_register_keep_me_logged_in', '', 'yes'),
(140, 'widget_useful-banner-manager-banners-rotation', 'a:5:{i:2;a:6:{s:5:"title";s:0:"";s:11:"banners_ids";a:2:{i:0;s:1:"9";i:1;s:2:"10";}s:8:"interval";s:2:"10";s:5:"width";s:3:"900";s:6:"height";s:3:"105";s:7:"orderby";s:16:"banner_order, id";}i:4;a:6:{s:5:"title";s:0:"";s:11:"banners_ids";a:2:{i:0;s:1:"3";i:1;s:1:"4";}s:8:"interval";s:2:"10";s:5:"width";s:3:"233";s:6:"height";s:3:"115";s:7:"orderby";s:16:"banner_order, id";}i:5;a:6:{s:5:"title";s:0:"";s:11:"banners_ids";a:2:{i:0;s:1:"5";i:1;s:1:"6";}s:8:"interval";s:2:"10";s:5:"width";s:3:"233";s:6:"height";s:3:"223";s:7:"orderby";s:16:"banner_order, id";}i:6;a:6:{s:5:"title";s:0:"";s:11:"banners_ids";a:2:{i:0;s:1:"7";i:1;s:1:"8";}s:8:"interval";s:2:"10";s:5:"width";s:3:"233";s:6:"height";s:2:"75";s:7:"orderby";s:16:"banner_order, id";}s:12:"_multiwidget";i:1;}', 'yes'),
(141, 'WPLANG', '', 'yes'),
(152, 'category_children', 'a:1:{i:9;a:7:{i:0;i:10;i:1;i:11;i:2;i:12;i:3;i:13;i:4;i:14;i:5;i:15;i:6;i:16;}}', 'yes'),
(153, '_wpfifc_taxonomy_term_database_version_', '132', 'yes'),
(154, 'wpfifc_image_padding', '2', 'yes'),
(155, 'wpfifc_default_columns', '3', 'yes'),
(156, 'wpfifc_default_size', '', 'yes'),
(157, 'wpfifc_genesis_taxonomy', '', 'yes'),
(158, 'wpfifc_genesis_position', '', 'yes'),
(161, 'widget_wpfifc_widget', 'a:2:{i:2;a:7:{s:15:"wpfifc_taxonomy";s:8:"category";s:14:"wpfifc_columns";s:1:"1";s:16:"wpfifc_imagesize";s:9:"thumbnail";s:14:"wpfifc_padding";s:1:"2";s:14:"wpfifc_orderby";s:4:"name";s:12:"wpfifc_order";s:3:"ASC";s:16:"wpfifc_hideempty";i:1;}s:12:"_multiwidget";i:1;}', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE IF NOT EXISTS `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=331 ;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 4, '_edit_last', '1'),
(3, 4, '_edit_lock', '1413611676:1'),
(4, 5, '_edit_last', '1'),
(5, 5, '_edit_lock', '1413613277:1'),
(6, 5, '_wp_page_template', 'announcements.php'),
(7, 7, '_form', '<p>Your Name (required)<br />\n    [text* your-name] </p>\n\n<p>Your Email (required)<br />\n    [email* your-email] </p>\n\n<p>Subject<br />\n    [text your-subject] </p>\n\n<p>Your Message<br />\n    [textarea your-message] </p>\n\n<p>[submit "Send"]</p>'),
(8, 7, '_mail', 'a:8:{s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:182:"From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n--\nThis e-mail was sent from a contact form on imagereality (http://192.168.1.77/imagereality)";s:9:"recipient";s:23:"poonam@amarinfotech.com";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(9, 7, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:124:"Message Body:\n[your-message]\n\n--\nThis e-mail was sent from a contact form on imagereality (http://192.168.1.77/imagereality)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(10, 7, '_messages', 'a:21:{s:12:"mail_sent_ok";s:43:"Your message was sent successfully. Thanks.";s:12:"mail_sent_ng";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:16:"validation_error";s:74:"Validation errors occurred. Please confirm the fields and submit it again.";s:4:"spam";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:12:"accept_terms";s:35:"Please accept the terms to proceed.";s:16:"invalid_required";s:31:"Please fill the required field.";s:17:"captcha_not_match";s:31:"Your entered code is incorrect.";s:14:"invalid_number";s:28:"Number format seems invalid.";s:16:"number_too_small";s:25:"This number is too small.";s:16:"number_too_large";s:25:"This number is too large.";s:13:"invalid_email";s:28:"Email address seems invalid.";s:11:"invalid_url";s:18:"URL seems invalid.";s:11:"invalid_tel";s:31:"Telephone number seems invalid.";s:23:"quiz_answer_not_correct";s:27:"Your answer is not correct.";s:12:"invalid_date";s:26:"Date format seems invalid.";s:14:"date_too_early";s:23:"This date is too early.";s:13:"date_too_late";s:22:"This date is too late.";s:13:"upload_failed";s:22:"Failed to upload file.";s:24:"upload_file_type_invalid";s:30:"This file type is not allowed.";s:21:"upload_file_too_large";s:23:"This file is too large.";s:23:"upload_failed_php_error";s:38:"Failed to upload file. Error occurred.";}'),
(11, 7, '_additional_settings', ''),
(12, 7, '_locale', 'en_US'),
(13, 9, '_edit_last', '1'),
(14, 9, '_edit_lock', '1413612180:1'),
(15, 9, '_wp_page_template', 'default'),
(16, 11, '_edit_last', '1'),
(17, 11, '_wp_page_template', 'contact.php'),
(18, 11, '_edit_lock', '1413619846:1'),
(19, 13, '_edit_last', '1'),
(20, 13, '_edit_lock', '1413620324:1'),
(21, 13, '_wp_page_template', 'dashboard.php'),
(22, 15, '_edit_last', '1'),
(23, 15, '_edit_lock', '1413612366:1'),
(24, 15, '_wp_page_template', 'default'),
(25, 17, '_edit_last', '1'),
(26, 17, '_wp_page_template', 'default'),
(27, 17, '_edit_lock', '1413612471:1'),
(28, 4, '_wp_trash_meta_status', 'draft'),
(29, 4, '_wp_trash_meta_time', '1413613110'),
(30, 20, '_edit_last', '1'),
(31, 20, '_wp_page_template', 'default'),
(32, 20, '_edit_lock', '1413613495:1'),
(33, 22, '_edit_last', '1'),
(34, 22, '_edit_lock', '1413613619:1'),
(35, 22, '_wp_page_template', 'News.php'),
(36, 24, '_edit_last', '1'),
(37, 24, '_edit_lock', '1413614192:1'),
(38, 24, '_wp_page_template', 'properties.php'),
(39, 26, '_edit_last', '1'),
(40, 26, '_edit_lock', '1413624434:1'),
(41, 26, '_wp_page_template', 'QandA.php'),
(42, 28, '_edit_last', '1'),
(43, 28, '_edit_lock', '1413619773:1'),
(44, 28, '_wp_page_template', 'reach_us.php'),
(45, 30, '_edit_last', '1'),
(46, 30, '_edit_lock', '1413620375:1'),
(47, 30, '_wp_page_template', 'Register.php'),
(48, 32, '_edit_last', '1'),
(49, 32, '_edit_lock', '1413613873:1'),
(50, 32, '_wp_page_template', 'default'),
(51, 33, '_edit_last', '1'),
(52, 33, '_edit_lock', '1413613899:1'),
(53, 33, '_wp_page_template', 'default'),
(54, 34, '_edit_last', '1'),
(55, 34, '_wp_page_template', 'default'),
(56, 34, '_edit_lock', '1413613915:1'),
(57, 35, '_edit_last', '1'),
(58, 35, '_edit_lock', '1413613973:1'),
(59, 35, '_wp_page_template', 'default'),
(60, 36, '_edit_last', '1'),
(61, 36, '_edit_lock', '1413619555:1'),
(62, 36, '_wp_page_template', 'default'),
(90, 45, '_menu_item_type', 'post_type'),
(91, 45, '_menu_item_menu_item_parent', '0'),
(92, 45, '_menu_item_object_id', '32'),
(93, 45, '_menu_item_object', 'page'),
(94, 45, '_menu_item_target', ''),
(95, 45, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(96, 45, '_menu_item_xfn', ''),
(97, 45, '_menu_item_url', ''),
(99, 46, '_menu_item_type', 'post_type'),
(100, 46, '_menu_item_menu_item_parent', '0'),
(101, 46, '_menu_item_object_id', '17'),
(102, 46, '_menu_item_object', 'page'),
(103, 46, '_menu_item_target', ''),
(104, 46, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(105, 46, '_menu_item_xfn', ''),
(106, 46, '_menu_item_url', ''),
(108, 48, '_menu_item_type', 'post_type'),
(109, 48, '_menu_item_menu_item_parent', '0'),
(110, 48, '_menu_item_object_id', '24'),
(111, 48, '_menu_item_object', 'page'),
(112, 48, '_menu_item_target', ''),
(113, 48, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(114, 48, '_menu_item_xfn', ''),
(115, 48, '_menu_item_url', ''),
(117, 49, '_menu_item_type', 'custom'),
(118, 49, '_menu_item_menu_item_parent', '0'),
(119, 49, '_menu_item_object_id', '49'),
(120, 49, '_menu_item_object', 'custom'),
(121, 49, '_menu_item_target', ''),
(122, 49, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(123, 49, '_menu_item_xfn', ''),
(124, 49, '_menu_item_url', 'http://192.168.1.77/imagereality/'),
(126, 50, '_menu_item_type', 'post_type'),
(127, 50, '_menu_item_menu_item_parent', '0'),
(128, 50, '_menu_item_object_id', '5'),
(129, 50, '_menu_item_object', 'page'),
(130, 50, '_menu_item_target', ''),
(131, 50, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(132, 50, '_menu_item_xfn', ''),
(133, 50, '_menu_item_url', ''),
(135, 51, '_menu_item_type', 'post_type'),
(136, 51, '_menu_item_menu_item_parent', '0'),
(137, 51, '_menu_item_object_id', '11'),
(138, 51, '_menu_item_object', 'page'),
(139, 51, '_menu_item_target', ''),
(140, 51, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(141, 51, '_menu_item_xfn', ''),
(142, 51, '_menu_item_url', ''),
(144, 52, '_menu_item_type', 'post_type'),
(145, 52, '_menu_item_menu_item_parent', '0'),
(146, 52, '_menu_item_object_id', '20'),
(147, 52, '_menu_item_object', 'page'),
(148, 52, '_menu_item_target', ''),
(149, 52, '_menu_item_classes', 'a:1:{i:0;s:5:"login";}'),
(150, 52, '_menu_item_xfn', ''),
(151, 52, '_menu_item_url', ''),
(153, 53, '_menu_item_type', 'post_type'),
(154, 53, '_menu_item_menu_item_parent', '0'),
(155, 53, '_menu_item_object_id', '22'),
(156, 53, '_menu_item_object', 'page'),
(157, 53, '_menu_item_target', ''),
(158, 53, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(159, 53, '_menu_item_xfn', ''),
(160, 53, '_menu_item_url', ''),
(162, 54, '_menu_item_type', 'post_type'),
(163, 54, '_menu_item_menu_item_parent', '0'),
(164, 54, '_menu_item_object_id', '26'),
(165, 54, '_menu_item_object', 'page'),
(166, 54, '_menu_item_target', ''),
(167, 54, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(168, 54, '_menu_item_xfn', ''),
(169, 54, '_menu_item_url', ''),
(171, 55, '_menu_item_type', 'post_type'),
(172, 55, '_menu_item_menu_item_parent', '0'),
(173, 55, '_menu_item_object_id', '28'),
(174, 55, '_menu_item_object', 'page'),
(175, 55, '_menu_item_target', ''),
(176, 55, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(177, 55, '_menu_item_xfn', ''),
(178, 55, '_menu_item_url', ''),
(180, 56, '_menu_item_type', 'post_type'),
(181, 56, '_menu_item_menu_item_parent', '0'),
(182, 56, '_menu_item_object_id', '30'),
(183, 56, '_menu_item_object', 'page'),
(184, 56, '_menu_item_target', ''),
(185, 56, '_menu_item_classes', 'a:1:{i:0;s:8:"Register";}'),
(186, 56, '_menu_item_xfn', ''),
(187, 56, '_menu_item_url', ''),
(189, 57, '_edit_last', '1'),
(190, 57, '_wp_page_template', 'default'),
(191, 57, '_edit_lock', '1413614448:1'),
(192, 59, '_menu_item_type', 'post_type'),
(193, 59, '_menu_item_menu_item_parent', '0'),
(194, 59, '_menu_item_object_id', '57'),
(195, 59, '_menu_item_object', 'page'),
(196, 59, '_menu_item_target', ''),
(197, 59, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(198, 59, '_menu_item_xfn', ''),
(199, 59, '_menu_item_url', ''),
(201, 60, '_menu_item_type', 'post_type'),
(202, 60, '_menu_item_menu_item_parent', '0'),
(203, 60, '_menu_item_object_id', '20'),
(204, 60, '_menu_item_object', 'page'),
(205, 60, '_menu_item_target', ''),
(206, 60, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(207, 60, '_menu_item_xfn', ''),
(208, 60, '_menu_item_url', ''),
(210, 61, '_menu_item_type', 'custom'),
(211, 61, '_menu_item_menu_item_parent', '0'),
(212, 61, '_menu_item_object_id', '61'),
(213, 61, '_menu_item_object', 'custom'),
(214, 61, '_menu_item_target', ''),
(215, 61, '_menu_item_classes', 'a:1:{i:0;s:4:"so_1";}'),
(216, 61, '_menu_item_xfn', ''),
(217, 61, '_menu_item_url', 'http://www.twitter.com/'),
(219, 62, '_menu_item_type', 'custom'),
(220, 62, '_menu_item_menu_item_parent', '0'),
(221, 62, '_menu_item_object_id', '62'),
(222, 62, '_menu_item_object', 'custom'),
(223, 62, '_menu_item_target', ''),
(224, 62, '_menu_item_classes', 'a:1:{i:0;s:4:"so_2";}'),
(225, 62, '_menu_item_xfn', ''),
(226, 62, '_menu_item_url', 'http://www.facebook.com/'),
(228, 63, '_menu_item_type', 'custom'),
(229, 63, '_menu_item_menu_item_parent', '0'),
(230, 63, '_menu_item_object_id', '63'),
(231, 63, '_menu_item_object', 'custom'),
(232, 63, '_menu_item_target', ''),
(233, 63, '_menu_item_classes', 'a:1:{i:0;s:4:"so_3";}'),
(234, 63, '_menu_item_xfn', ''),
(235, 63, '_menu_item_url', 'http://www.youtube.com/'),
(237, 64, '_menu_item_type', 'custom'),
(238, 64, '_menu_item_menu_item_parent', '0'),
(239, 64, '_menu_item_object_id', '64'),
(240, 64, '_menu_item_object', 'custom'),
(241, 64, '_menu_item_target', ''),
(242, 64, '_menu_item_classes', 'a:1:{i:0;s:4:"so_4";}'),
(243, 64, '_menu_item_xfn', ''),
(244, 64, '_menu_item_url', 'http://www.instagram.com/'),
(246, 65, '_menu_item_type', 'custom'),
(247, 65, '_menu_item_menu_item_parent', '0'),
(248, 65, '_menu_item_object_id', '65'),
(249, 65, '_menu_item_object', 'custom'),
(250, 65, '_menu_item_target', ''),
(251, 65, '_menu_item_classes', 'a:1:{i:0;s:4:"so_5";}'),
(252, 65, '_menu_item_xfn', ''),
(253, 65, '_menu_item_url', 'http://www.linkedin.com/'),
(255, 66, '_menu_item_type', 'custom'),
(256, 66, '_menu_item_menu_item_parent', '0'),
(257, 66, '_menu_item_object_id', '66'),
(258, 66, '_menu_item_object', 'custom'),
(259, 66, '_menu_item_target', ''),
(260, 66, '_menu_item_classes', 'a:1:{i:0;s:4:"so_6";}'),
(261, 66, '_menu_item_xfn', ''),
(262, 66, '_menu_item_url', 'https://plus.google.com/'),
(264, 36, 'sub_content', 'We all are about long-term client relations, we have come to the real estate market to offer a distinguished aspect of integrity, client''s best invest, and a win-win relationship, these are core values that we take pride in.'),
(266, 68, '_menu_item_type', 'post_type'),
(267, 68, '_menu_item_menu_item_parent', '0'),
(268, 68, '_menu_item_object_id', '36'),
(269, 68, '_menu_item_object', 'page'),
(270, 68, '_menu_item_target', ''),
(271, 68, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(272, 68, '_menu_item_xfn', ''),
(273, 68, '_menu_item_url', ''),
(275, 69, '_menu_item_type', 'post_type'),
(276, 69, '_menu_item_menu_item_parent', '0'),
(277, 69, '_menu_item_object_id', '33'),
(278, 69, '_menu_item_object', 'page'),
(279, 69, '_menu_item_target', ''),
(280, 69, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(281, 69, '_menu_item_xfn', ''),
(282, 69, '_menu_item_url', ''),
(284, 70, '_menu_item_type', 'post_type'),
(285, 70, '_menu_item_menu_item_parent', '0'),
(286, 70, '_menu_item_object_id', '35'),
(287, 70, '_menu_item_object', 'page'),
(288, 70, '_menu_item_target', ''),
(289, 70, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(290, 70, '_menu_item_xfn', ''),
(291, 70, '_menu_item_url', ''),
(293, 71, '_form', '<p>Your Name (required)<br />\n    [text* your-name] </p>\n\n<p>Your Email (required)<br />\n    [email* your-email] </p>\n\n<p>Subject<br />\n    [text your-subject] </p>\n\n<p>select category<br/>\n[select* menu-534 "Query" "Suggestion" "Feedback"]</p>\n\n<p>Your Message<br />\n    [textarea your-message] </p>\n\n\n\n<p>[submit "Send"]</p>'),
(294, 71, '_mail', 'a:8:{s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:214:"From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nSelected Category: [menu-534]\n\nMessage Body:\n[your-message]\n\n\n--\nThis e-mail was sent from a contact form on imagereality (http://192.168.1.77/imagereality)";s:9:"recipient";s:23:"poonam@amarinfotech.com";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(295, 71, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:124:"Message Body:\n[your-message]\n\n--\nThis e-mail was sent from a contact form on imagereality (http://192.168.1.77/imagereality)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(296, 71, '_messages', 'a:21:{s:12:"mail_sent_ok";s:43:"Your message was sent successfully. Thanks.";s:12:"mail_sent_ng";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:16:"validation_error";s:74:"Validation errors occurred. Please confirm the fields and submit it again.";s:4:"spam";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:12:"accept_terms";s:35:"Please accept the terms to proceed.";s:16:"invalid_required";s:31:"Please fill the required field.";s:17:"captcha_not_match";s:31:"Your entered code is incorrect.";s:14:"invalid_number";s:28:"Number format seems invalid.";s:16:"number_too_small";s:25:"This number is too small.";s:16:"number_too_large";s:25:"This number is too large.";s:13:"invalid_email";s:28:"Email address seems invalid.";s:11:"invalid_url";s:18:"URL seems invalid.";s:11:"invalid_tel";s:31:"Telephone number seems invalid.";s:23:"quiz_answer_not_correct";s:27:"Your answer is not correct.";s:12:"invalid_date";s:26:"Date format seems invalid.";s:14:"date_too_early";s:23:"This date is too early.";s:13:"date_too_late";s:22:"This date is too late.";s:13:"upload_failed";s:22:"Failed to upload file.";s:24:"upload_file_type_invalid";s:30:"This file type is not allowed.";s:21:"upload_file_too_large";s:23:"This file is too large.";s:23:"upload_failed_php_error";s:38:"Failed to upload file. Error occurred.";}'),
(297, 71, '_additional_settings', ''),
(298, 71, '_locale', 'en_US'),
(299, 72, '_edit_last', '1'),
(300, 72, '_wp_page_template', 'default'),
(301, 72, '_edit_lock', '1413620563:1'),
(302, 74, '_edit_lock', '1413623105:1'),
(303, 74, '_edit_last', '1'),
(304, 75, '_edit_lock', '1413623139:1'),
(305, 75, '_edit_last', '1'),
(306, 76, '_edit_lock', '1413623261:1'),
(307, 76, '_edit_last', '1'),
(308, 77, '_edit_last', '1'),
(309, 77, '_edit_lock', '1413623286:1'),
(310, 78, '_edit_last', '1'),
(311, 78, '_edit_lock', '1413623381:1'),
(312, 79, '_edit_lock', '1413623380:1'),
(313, 79, '_edit_last', '1'),
(314, 82, '_wp_attached_file', '2014/10/background.jpg'),
(315, 82, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1920;s:6:"height";i:1009;s:4:"file";s:22:"2014/10/background.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"background-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"background-300x157.jpg";s:5:"width";i:300;s:6:"height";i:157;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"background-1024x538.jpg";s:5:"width";i:1024;s:6:"height";i:538;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(316, 81, '_thumbnail_id', '82'),
(317, 83, '_edit_lock', '1413628258:1'),
(318, 84, '_edit_lock', '1413628663:1'),
(319, 85, '_edit_lock', '1413641822:1'),
(320, 85, '_edit_last', '1'),
(321, 85, '_wp_page_template', 'default'),
(322, 87, '_edit_last', '1'),
(323, 87, '_wp_page_template', 'default'),
(324, 87, '_edit_lock', '1413636710:1'),
(325, 88, '_edit_last', '1'),
(326, 88, '_wp_page_template', 'default'),
(327, 88, '_edit_lock', '1413636711:1'),
(328, 91, '_edit_last', '1'),
(329, 91, '_wp_page_template', 'default'),
(330, 91, '_edit_lock', '1413636709:1');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE IF NOT EXISTS `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=93 ;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2014-10-18 05:45:39', '2014-10-18 05:45:39', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2014-10-18 05:45:39', '2014-10-18 05:45:39', '', 0, 'http://192.168.1.77/imagereality/?p=1', 0, 'post', '', 1),
(2, 1, '2014-10-18 05:45:39', '2014-10-18 05:45:39', 'This is an example page. It''s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I''m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin'' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://192.168.1.77/imagereality/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'open', 'open', '', 'sample-page', '', '', '2014-10-18 05:45:39', '2014-10-18 05:45:39', '', 0, 'http://192.168.1.77/imagereality/?page_id=2', 0, 'page', '', 0),
(3, 1, '2014-10-18 05:46:10', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-10-18 05:46:10', '0000-00-00 00:00:00', '', 0, 'http://192.168.1.77/imagereality/?p=3', 0, 'post', '', 0),
(4, 1, '2014-10-18 05:54:35', '2014-10-18 05:54:35', '', 'Announcements', '', 'trash', 'open', 'open', '', 'announcements-2', '', '', '2014-10-18 06:18:30', '2014-10-18 06:18:30', '', 0, 'http://192.168.1.77/imagereality/?page_id=4', 0, 'page', '', 0),
(5, 1, '2014-10-18 06:01:09', '2014-10-18 06:01:09', '', 'Announcements', '', 'publish', 'open', 'open', '', 'announcements', '', '', '2014-10-18 06:18:42', '2014-10-18 06:18:42', '', 0, 'http://192.168.1.77/imagereality/?page_id=5', 0, 'page', '', 0),
(6, 1, '2014-10-18 06:01:09', '2014-10-18 06:01:09', '', 'Announcements', '', 'inherit', 'open', 'open', '', '5-revision-v1', '', '', '2014-10-18 06:01:09', '2014-10-18 06:01:09', '', 5, 'http://192.168.1.77/imagereality/?p=6', 0, 'revision', '', 0),
(7, 1, '2014-10-18 06:02:52', '2014-10-18 06:02:52', '<p>Your Name (required)<br />\r\n    [text* your-name] </p>\r\n\r\n<p>Your Email (required)<br />\r\n    [email* your-email] </p>\r\n\r\n<p>Subject<br />\r\n    [text your-subject] </p>\r\n\r\n<p>Your Message<br />\r\n    [textarea your-message] </p>\r\n\r\n<p>[submit "Send"]</p>\n[your-subject]\n[your-name] <[your-email]>\nFrom: [your-name] <[your-email]>\r\nSubject: [your-subject]\r\n\r\nMessage Body:\r\n[your-message]\r\n\r\n--\r\nThis e-mail was sent from a contact form on imagereality (http://192.168.1.77/imagereality)\npoonam@amarinfotech.com\n\n\n\n\n\n[your-subject]\n[your-name] <[your-email]>\nMessage Body:\r\n[your-message]\r\n\r\n--\r\nThis e-mail was sent from a contact form on imagereality (http://192.168.1.77/imagereality)\n[your-email]\n\n\n\n\nYour message was sent successfully. Thanks.\nFailed to send your message. Please try later or contact the administrator by another method.\nValidation errors occurred. Please confirm the fields and submit it again.\nFailed to send your message. Please try later or contact the administrator by another method.\nPlease accept the terms to proceed.\nPlease fill the required field.\nYour entered code is incorrect.\nNumber format seems invalid.\nThis number is too small.\nThis number is too large.\nEmail address seems invalid.\nURL seems invalid.\nTelephone number seems invalid.\nYour answer is not correct.\nDate format seems invalid.\nThis date is too early.\nThis date is too late.\nFailed to upload file.\nThis file type is not allowed.\nThis file is too large.\nFailed to upload file. Error occurred.', 'Contact form 1', '', 'publish', 'open', 'open', '', 'contact-form-1', '', '', '2014-10-18 08:02:21', '2014-10-18 08:02:21', '', 0, 'http://192.168.1.77/imagereality/?post_type=wpcf7_contact_form&#038;p=7', 0, 'wpcf7_contact_form', '', 0),
(8, 1, '2014-10-18 06:04:06', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-10-18 06:04:06', '0000-00-00 00:00:00', '', 0, 'http://192.168.1.77/imagereality/?page_id=8', 0, 'page', '', 0),
(9, 1, '2014-10-18 06:05:05', '2014-10-18 06:05:05', '', 'Careers', '', 'publish', 'open', 'open', '', 'careers', '', '', '2014-10-18 06:05:05', '2014-10-18 06:05:05', '', 0, 'http://192.168.1.77/imagereality/?page_id=9', 0, 'page', '', 0),
(10, 1, '2014-10-18 06:05:05', '2014-10-18 06:05:05', '', 'Careers', '', 'inherit', 'open', 'open', '', '9-revision-v1', '', '', '2014-10-18 06:05:05', '2014-10-18 06:05:05', '', 9, 'http://192.168.1.77/imagereality/?p=10', 0, 'revision', '', 0),
(11, 1, '2014-10-18 06:05:34', '2014-10-18 06:05:34', '', 'Contact', '', 'publish', 'open', 'open', '', 'contact', '', '', '2014-10-18 08:12:39', '2014-10-18 08:12:39', '', 0, 'http://192.168.1.77/imagereality/?page_id=11', 0, 'page', '', 0),
(12, 1, '2014-10-18 06:05:34', '2014-10-18 06:05:34', '', 'Contact', '', 'inherit', 'open', 'open', '', '11-revision-v1', '', '', '2014-10-18 06:05:34', '2014-10-18 06:05:34', '', 11, 'http://192.168.1.77/imagereality/?p=12', 0, 'revision', '', 0),
(13, 1, '2014-10-18 06:06:00', '2014-10-18 06:06:00', '', 'Dashboard', '', 'publish', 'open', 'open', '', 'dashboard', '', '', '2014-10-18 06:07:14', '2014-10-18 06:07:14', '', 0, 'http://192.168.1.77/imagereality/?page_id=13', 0, 'page', '', 0),
(14, 1, '2014-10-18 06:06:00', '2014-10-18 06:06:00', '', 'Dashboard', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-10-18 06:06:00', '2014-10-18 06:06:00', '', 13, 'http://192.168.1.77/imagereality/?p=14', 0, 'revision', '', 0),
(15, 1, '2014-10-18 06:08:08', '2014-10-18 06:08:08', '', 'Home', '', 'publish', 'open', 'open', '', 'home', '', '', '2014-10-18 06:08:08', '2014-10-18 06:08:08', '', 0, 'http://192.168.1.77/imagereality/?page_id=15', 0, 'page', '', 0),
(16, 1, '2014-10-18 06:08:08', '2014-10-18 06:08:08', '', 'Home', '', 'inherit', 'open', 'open', '', '15-revision-v1', '', '', '2014-10-18 06:08:08', '2014-10-18 06:08:08', '', 15, 'http://192.168.1.77/imagereality/?p=16', 0, 'revision', '', 0),
(17, 1, '2014-10-18 06:08:42', '2014-10-18 06:08:42', '', 'LISTINGS', '', 'publish', 'open', 'open', '', 'listings', '', '', '2014-10-18 06:08:42', '2014-10-18 06:08:42', '', 0, 'http://192.168.1.77/imagereality/?page_id=17', 0, 'page', '', 0),
(18, 1, '2014-10-18 06:08:42', '2014-10-18 06:08:42', '', 'LISTINGS', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2014-10-18 06:08:42', '2014-10-18 06:08:42', '', 17, 'http://192.168.1.77/imagereality/?p=18', 0, 'revision', '', 0),
(19, 1, '2014-10-18 06:18:30', '2014-10-18 06:18:30', '', 'Announcements', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-10-18 06:18:30', '2014-10-18 06:18:30', '', 4, 'http://192.168.1.77/imagereality/?p=19', 0, 'revision', '', 0),
(20, 1, '2014-10-18 06:26:56', '2014-10-18 06:26:56', '', 'Login', '', 'publish', 'open', 'open', '', 'login', '', '', '2014-10-18 06:26:56', '2014-10-18 06:26:56', '', 0, 'http://192.168.1.77/imagereality/?page_id=20', 0, 'page', '', 0),
(21, 1, '2014-10-18 06:26:56', '2014-10-18 06:26:56', '', 'Login', '', 'inherit', 'open', 'open', '', '20-revision-v1', '', '', '2014-10-18 06:26:56', '2014-10-18 06:26:56', '', 20, 'http://192.168.1.77/imagereality/?p=21', 0, 'revision', '', 0),
(22, 1, '2014-10-18 06:28:25', '2014-10-18 06:28:25', '', 'News', '', 'publish', 'open', 'open', '', 'news', '', '', '2014-10-18 06:28:25', '2014-10-18 06:28:25', '', 0, 'http://192.168.1.77/imagereality/?page_id=22', 0, 'page', '', 0),
(23, 1, '2014-10-18 06:28:25', '2014-10-18 06:28:25', '', 'News', '', 'inherit', 'open', 'open', '', '22-revision-v1', '', '', '2014-10-18 06:28:25', '2014-10-18 06:28:25', '', 22, 'http://192.168.1.77/imagereality/?p=23', 0, 'revision', '', 0),
(24, 1, '2014-10-18 06:29:40', '2014-10-18 06:29:40', '', 'PROPERTIES', '', 'publish', 'open', 'open', '', 'properties', '', '', '2014-10-18 06:38:51', '2014-10-18 06:38:51', '', 0, 'http://192.168.1.77/imagereality/?page_id=24', 0, 'page', '', 0),
(25, 1, '2014-10-18 06:29:40', '2014-10-18 06:29:40', '', 'Properties', '', 'inherit', 'open', 'open', '', '24-revision-v1', '', '', '2014-10-18 06:29:40', '2014-10-18 06:29:40', '', 24, 'http://192.168.1.77/imagereality/?p=25', 0, 'revision', '', 0),
(26, 1, '2014-10-18 06:30:13', '2014-10-18 06:30:13', '', 'Q & A', '', 'publish', 'open', 'open', '', 'q-a', '', '', '2014-10-18 06:30:13', '2014-10-18 06:30:13', '', 0, 'http://192.168.1.77/imagereality/?page_id=26', 0, 'page', '', 0),
(27, 1, '2014-10-18 06:30:13', '2014-10-18 06:30:13', '', 'Q & A', '', 'inherit', 'open', 'open', '', '26-revision-v1', '', '', '2014-10-18 06:30:13', '2014-10-18 06:30:13', '', 26, 'http://192.168.1.77/imagereality/?p=27', 0, 'revision', '', 0),
(28, 1, '2014-10-18 06:30:38', '2014-10-18 06:30:38', '', 'ReachUs', '', 'publish', 'open', 'open', '', 'reachus', '', '', '2014-10-18 08:11:34', '2014-10-18 08:11:34', '', 0, 'http://192.168.1.77/imagereality/?page_id=28', 0, 'page', '', 0),
(29, 1, '2014-10-18 06:30:38', '2014-10-18 06:30:38', '', 'ReachUs', '', 'inherit', 'open', 'open', '', '28-revision-v1', '', '', '2014-10-18 06:30:38', '2014-10-18 06:30:38', '', 28, 'http://192.168.1.77/imagereality/?p=29', 0, 'revision', '', 0),
(30, 1, '2014-10-18 06:32:14', '2014-10-18 06:32:14', '', 'Register', '', 'publish', 'open', 'open', '', 'register', '', '', '2014-10-18 06:32:14', '2014-10-18 06:32:14', '', 0, 'http://192.168.1.77/imagereality/?page_id=30', 0, 'page', '', 0),
(31, 1, '2014-10-18 06:32:14', '2014-10-18 06:32:14', '', 'Register', '', 'inherit', 'open', 'open', '', '30-revision-v1', '', '', '2014-10-18 06:32:14', '2014-10-18 06:32:14', '', 30, 'http://192.168.1.77/imagereality/?p=31', 0, 'revision', '', 0),
(32, 1, '2014-10-18 06:33:31', '2014-10-18 06:33:31', '<div class="content_sub_heading">Search & Locate Utility</div>\r\n<div class="content_data">Since....., Image real estate has marketing for the biggest real estate projects in Egypt. Our traines sales management and crew have a vast experience in new cities and compounds marketing. Our clients include high profiel names and key construction and development entities.</div><br>\r\n\r\n<div class="content_sub_heading">How to Navigate</div>\r\n<div class="content_data">Image''s experience in creating feasibility studies and market research for real estate projects enables it to be your sole advisor when thinking of estabilishing a new real estate project. If you are looking to start a new project within real estate field, Image will act as your advisor and project manager throughout the whole process, ensuring your best interest, short turn-around, and highest revenues. </div><br>\r\n\r\n', 'SEARCH & LOCATE', '', 'publish', 'open', 'open', '', 'search-locate', '', '', '2014-10-18 06:33:31', '2014-10-18 06:33:31', '', 0, 'http://192.168.1.77/imagereality/?page_id=32', 0, 'page', '', 0),
(33, 1, '2014-10-18 06:33:54', '2014-10-18 06:33:54', '<div class="content_sub_heading">Project Marketing</div>\r\n<div class="content_data">Since....., Image real estate has marketing for the biggest real estate projects in Egypt. Our trained sale management and crew have a vast experience in new cities and compounds marketing. Our clients include high profile names and key construction and development entities. </div><br>\r\n\r\n<div class="content_sub_heading">Consultation</div>\r\n<div class="content_data">Image''s experience in creating feasibility studies and market research for real estate projects enables to be your sole advisor when thinking of establishing a new real estate project. If you are looking to start a new project within the real estate field, Image will act as your advisor and project manager throughout the whole process, ensuring your best interest, short turn-around, and highest revenues.</div><br>\r\n\r\n<div class="content_sub_heading">Private Units</div>\r\n<div class="content_data">Image helps you to sell, buy, or rent any private unit. Whether its your office, apartment or villa, you can do all your real estate transactions without the hassle of an unprofessional agent. Because Image has a vast real estate network, our choice for you is based on your interest, as we act as promoters for various entities and are not limited to just one exclusive project. No more shall you suffer with an untrustworthy agent, as we offer you the best and most credible services you can get.</div><br>\r\n\r\n\r\n', 'SERVICES', '', 'publish', 'open', 'open', '', 'services', '', '', '2014-10-18 06:33:54', '2014-10-18 06:33:54', '', 0, 'http://192.168.1.77/imagereality/?page_id=33', 0, 'page', '', 0),
(34, 1, '2014-10-18 06:34:15', '2014-10-18 06:34:15', '', 'Sitemap', '', 'publish', 'open', 'open', '', 'sitemap', '', '', '2014-10-18 06:34:15', '2014-10-18 06:34:15', '', 0, 'http://192.168.1.77/imagereality/?page_id=34', 0, 'page', '', 0),
(35, 1, '2014-10-18 06:34:37', '2014-10-18 06:34:37', '', 'WHAT WE DO', '', 'publish', 'open', 'open', '', 'what-we-do', '', '', '2014-10-18 06:34:37', '2014-10-18 06:34:37', '', 0, 'http://192.168.1.77/imagereality/?page_id=35', 0, 'page', '', 0),
(36, 1, '2014-10-18 06:34:57', '2014-10-18 06:34:57', '<div class="content_sub_heading">Our Vision</div>\r\n<div class="content_data">To be the foemost real estate consultancy firm in Egypt, serving our clients with excellence and efficiency </div><br>\r\n\r\n\r\n<div class="content_sub_heading">Our Mission</div>\r\n<div class="content_data">Helping our clients whether corporates or individuals to attain the best real estate deals in Egypt with integrity and effectiveness.</div>', 'WHY MOVE IN', '', 'publish', 'open', 'open', '', 'why-move-in', '', '', '2014-10-18 07:48:13', '2014-10-18 07:48:13', '', 0, 'http://192.168.1.77/imagereality/?page_id=36', 0, 'page', '', 0),
(37, 1, '2014-10-18 06:33:31', '2014-10-18 06:33:31', '<div class="content_sub_heading">Search & Locate Utility</div>\r\n<div class="content_data">Since....., Image real estate has marketing for the biggest real estate projects in Egypt. Our traines sales management and crew have a vast experience in new cities and compounds marketing. Our clients include high profiel names and key construction and development entities.</div><br>\r\n\r\n<div class="content_sub_heading">How to Navigate</div>\r\n<div class="content_data">Image''s experience in creating feasibility studies and market research for real estate projects enables it to be your sole advisor when thinking of estabilishing a new real estate project. If you are looking to start a new project within real estate field, Image will act as your advisor and project manager throughout the whole process, ensuring your best interest, short turn-around, and highest revenues. </div><br>\r\n\r\n', 'SEARCH & LOCATE', '', 'inherit', 'open', 'open', '', '32-revision-v1', '', '', '2014-10-18 06:33:31', '2014-10-18 06:33:31', '', 32, 'http://192.168.1.77/imagereality/?p=37', 0, 'revision', '', 0),
(38, 1, '2014-10-18 06:33:54', '2014-10-18 06:33:54', '<div class="content_sub_heading">Project Marketing</div>\r\n<div class="content_data">Since....., Image real estate has marketing for the biggest real estate projects in Egypt. Our trained sale management and crew have a vast experience in new cities and compounds marketing. Our clients include high profile names and key construction and development entities. </div><br>\r\n\r\n<div class="content_sub_heading">Consultation</div>\r\n<div class="content_data">Image''s experience in creating feasibility studies and market research for real estate projects enables to be your sole advisor when thinking of establishing a new real estate project. If you are looking to start a new project within the real estate field, Image will act as your advisor and project manager throughout the whole process, ensuring your best interest, short turn-around, and highest revenues.</div><br>\r\n\r\n<div class="content_sub_heading">Private Units</div>\r\n<div class="content_data">Image helps you to sell, buy, or rent any private unit. Whether its your office, apartment or villa, you can do all your real estate transactions without the hassle of an unprofessional agent. Because Image has a vast real estate network, our choice for you is based on your interest, as we act as promoters for various entities and are not limited to just one exclusive project. No more shall you suffer with an untrustworthy agent, as we offer you the best and most credible services you can get.</div><br>\r\n\r\n\r\n', 'SERVICES', '', 'inherit', 'open', 'open', '', '33-revision-v1', '', '', '2014-10-18 06:33:54', '2014-10-18 06:33:54', '', 33, 'http://192.168.1.77/imagereality/?p=38', 0, 'revision', '', 0),
(39, 1, '2014-10-18 06:34:15', '2014-10-18 06:34:15', '', 'Sitemap', '', 'inherit', 'open', 'open', '', '34-revision-v1', '', '', '2014-10-18 06:34:15', '2014-10-18 06:34:15', '', 34, 'http://192.168.1.77/imagereality/?p=39', 0, 'revision', '', 0),
(40, 1, '2014-10-18 06:34:37', '2014-10-18 06:34:37', '', 'WHAT WE DO', '', 'inherit', 'open', 'open', '', '35-revision-v1', '', '', '2014-10-18 06:34:37', '2014-10-18 06:34:37', '', 35, 'http://192.168.1.77/imagereality/?p=40', 0, 'revision', '', 0),
(41, 1, '2014-10-18 06:34:57', '2014-10-18 06:34:57', '&lt;div class="content_sub_heading"&gt;Our Vision&lt;/div&gt;\r\n&lt;div class="content_data"&gt;To be the foemost real estate consultancy firm in Egypt, serving our clients with excellence and efficiency &lt;/div&gt;&lt;br&gt;\r\n\r\n\r\n&lt;div class="content_sub_heading"&gt;Our Mission&lt;/div&gt;\r\n&lt;div class="content_data"&gt;Helping our clients whether corporates or individuals to attain the best real estate deals in Egypt with integrity and effectiveness.&lt;/div&gt;', 'WHY MOVE IN', '', 'inherit', 'open', 'open', '', '36-revision-v1', '', '', '2014-10-18 06:34:57', '2014-10-18 06:34:57', '', 36, 'http://192.168.1.77/imagereality/?p=41', 0, 'revision', '', 0),
(45, 1, '2014-10-18 06:37:55', '2014-10-18 06:37:55', ' ', '', '', 'publish', 'open', 'open', '', '45', '', '', '2014-10-18 07:55:34', '2014-10-18 07:55:34', '', 0, 'http://192.168.1.77/imagereality/?p=45', 5, 'nav_menu_item', '', 0),
(46, 1, '2014-10-18 06:37:55', '2014-10-18 06:37:55', ' ', '', '', 'publish', 'open', 'open', '', '46', '', '', '2014-10-18 07:55:34', '2014-10-18 07:55:34', '', 0, 'http://192.168.1.77/imagereality/?p=46', 6, 'nav_menu_item', '', 0),
(47, 1, '2014-10-18 06:38:51', '2014-10-18 06:38:51', '', 'PROPERTIES', '', 'inherit', 'open', 'open', '', '24-revision-v1', '', '', '2014-10-18 06:38:51', '2014-10-18 06:38:51', '', 24, 'http://192.168.1.77/imagereality/?p=47', 0, 'revision', '', 0),
(48, 1, '2014-10-18 06:39:52', '2014-10-18 06:39:52', ' ', '', '', 'publish', 'open', 'open', '', '48', '', '', '2014-10-18 07:55:33', '2014-10-18 07:55:33', '', 0, 'http://192.168.1.77/imagereality/?p=48', 3, 'nav_menu_item', '', 0),
(49, 1, '2014-10-18 06:42:23', '2014-10-18 06:42:23', '', 'Home', '', 'publish', 'open', 'open', '', 'home', '', '', '2014-10-18 08:20:29', '2014-10-18 08:20:29', '', 0, 'http://192.168.1.77/imagereality/?p=49', 1, 'nav_menu_item', '', 0),
(50, 1, '2014-10-18 06:42:23', '2014-10-18 06:42:23', ' ', '', '', 'publish', 'open', 'open', '', '50', '', '', '2014-10-18 08:20:29', '2014-10-18 08:20:29', '', 0, 'http://192.168.1.77/imagereality/?p=50', 4, 'nav_menu_item', '', 0),
(51, 1, '2014-10-18 06:42:23', '2014-10-18 06:42:23', ' ', '', '', 'publish', 'open', 'open', '', '51', '', '', '2014-10-18 08:20:29', '2014-10-18 08:20:29', '', 0, 'http://192.168.1.77/imagereality/?p=51', 5, 'nav_menu_item', '', 0),
(52, 1, '2014-10-18 06:42:24', '2014-10-18 06:42:24', ' ', '', '', 'publish', 'open', 'open', '', '52', '', '', '2014-10-18 08:20:29', '2014-10-18 08:20:29', '', 0, 'http://192.168.1.77/imagereality/?p=52', 7, 'nav_menu_item', '', 0),
(53, 1, '2014-10-18 06:42:23', '2014-10-18 06:42:23', ' ', '', '', 'publish', 'open', 'open', '', '53', '', '', '2014-10-18 08:20:29', '2014-10-18 08:20:29', '', 0, 'http://192.168.1.77/imagereality/?p=53', 2, 'nav_menu_item', '', 0),
(54, 1, '2014-10-18 06:42:23', '2014-10-18 06:42:23', ' ', '', '', 'publish', 'open', 'open', '', '54', '', '', '2014-10-18 08:20:29', '2014-10-18 08:20:29', '', 0, 'http://192.168.1.77/imagereality/?p=54', 3, 'nav_menu_item', '', 0),
(55, 1, '2014-10-18 06:42:24', '2014-10-18 06:42:24', ' ', '', '', 'publish', 'open', 'open', '', '55', '', '', '2014-10-18 08:20:29', '2014-10-18 08:20:29', '', 0, 'http://192.168.1.77/imagereality/?p=55', 6, 'nav_menu_item', '', 0),
(56, 1, '2014-10-18 06:42:24', '2014-10-18 06:42:24', ' ', '', '', 'publish', 'open', 'open', '', '56', '', '', '2014-10-18 08:20:29', '2014-10-18 08:20:29', '', 0, 'http://192.168.1.77/imagereality/?p=56', 8, 'nav_menu_item', '', 0),
(57, 1, '2014-10-18 06:43:06', '2014-10-18 06:43:06', '', 'English', '', 'publish', 'open', 'open', '', 'english', '', '', '2014-10-18 06:43:06', '2014-10-18 06:43:06', '', 0, 'http://192.168.1.77/imagereality/?page_id=57', 0, 'page', '', 0),
(58, 1, '2014-10-18 06:43:06', '2014-10-18 06:43:06', '', 'English', '', 'inherit', 'open', 'open', '', '57-revision-v1', '', '', '2014-10-18 06:43:06', '2014-10-18 06:43:06', '', 57, 'http://192.168.1.77/imagereality/?p=58', 0, 'revision', '', 0),
(59, 1, '2014-10-18 06:43:57', '2014-10-18 06:43:57', ' ', '', '', 'publish', 'open', 'open', '', '59', '', '', '2014-10-18 06:43:57', '2014-10-18 06:43:57', '', 0, 'http://192.168.1.77/imagereality/?p=59', 2, 'nav_menu_item', '', 0),
(60, 1, '2014-10-18 06:43:57', '2014-10-18 06:43:57', ' ', '', '', 'publish', 'open', 'open', '', '60', '', '', '2014-10-18 06:43:57', '2014-10-18 06:43:57', '', 0, 'http://192.168.1.77/imagereality/?p=60', 1, 'nav_menu_item', '', 0),
(61, 1, '2014-10-18 06:47:17', '2014-10-18 06:47:17', '', 'twitter', '', 'publish', 'open', 'open', '', 'twitter', '', '', '2014-10-18 06:48:53', '2014-10-18 06:48:53', '', 0, 'http://192.168.1.77/imagereality/?p=61', 1, 'nav_menu_item', '', 0),
(62, 1, '2014-10-18 06:47:17', '2014-10-18 06:47:17', '', 'facebook', '', 'publish', 'open', 'open', '', 'facebook', '', '', '2014-10-18 06:48:53', '2014-10-18 06:48:53', '', 0, 'http://192.168.1.77/imagereality/?p=62', 2, 'nav_menu_item', '', 0),
(63, 1, '2014-10-18 06:47:17', '2014-10-18 06:47:17', '', 'youtube', '', 'publish', 'open', 'open', '', 'youtube', '', '', '2014-10-18 06:48:53', '2014-10-18 06:48:53', '', 0, 'http://192.168.1.77/imagereality/?p=63', 3, 'nav_menu_item', '', 0),
(64, 1, '2014-10-18 06:47:17', '2014-10-18 06:47:17', '', 'instagram', '', 'publish', 'open', 'open', '', 'instagram', '', '', '2014-10-18 06:48:53', '2014-10-18 06:48:53', '', 0, 'http://192.168.1.77/imagereality/?p=64', 4, 'nav_menu_item', '', 0),
(65, 1, '2014-10-18 06:47:18', '2014-10-18 06:47:18', '', 'linkedin', '', 'publish', 'open', 'open', '', 'linkedin', '', '', '2014-10-18 06:48:54', '2014-10-18 06:48:54', '', 0, 'http://192.168.1.77/imagereality/?p=65', 5, 'nav_menu_item', '', 0),
(66, 1, '2014-10-18 06:47:18', '2014-10-18 06:47:18', '', 'plus_google', '', 'publish', 'open', 'open', '', 'plus_google', '', '', '2014-10-18 06:48:54', '2014-10-18 06:48:54', '', 0, 'http://192.168.1.77/imagereality/?p=66', 6, 'nav_menu_item', '', 0),
(67, 1, '2014-10-18 06:52:34', '2014-10-18 06:52:34', '<div class="content_sub_heading">Our Vision</div>\r\n<div class="content_data">To be the foemost real estate consultancy firm in Egypt, serving our clients with excellence and efficiency </div><br>\r\n\r\n\r\n<div class="content_sub_heading">Our Mission</div>\r\n<div class="content_data">Helping our clients whether corporates or individuals to attain the best real estate deals in Egypt with integrity and effectiveness.</div>', 'WHY MOVE IN', '', 'inherit', 'open', 'open', '', '36-revision-v1', '', '', '2014-10-18 06:52:34', '2014-10-18 06:52:34', '', 36, 'http://192.168.1.77/imagereality/?p=67', 0, 'revision', '', 0),
(68, 1, '2014-10-18 07:54:30', '2014-10-18 07:54:30', ' ', '', '', 'publish', 'open', 'open', '', '68', '', '', '2014-10-18 07:55:33', '2014-10-18 07:55:33', '', 0, 'http://192.168.1.77/imagereality/?p=68', 1, 'nav_menu_item', '', 0),
(69, 1, '2014-10-18 07:54:55', '2014-10-18 07:54:55', ' ', '', '', 'publish', 'open', 'open', '', '69', '', '', '2014-10-18 07:55:33', '2014-10-18 07:55:33', '', 0, 'http://192.168.1.77/imagereality/?p=69', 2, 'nav_menu_item', '', 0),
(70, 1, '2014-10-18 07:55:08', '2014-10-18 07:55:08', ' ', '', '', 'publish', 'open', 'open', '', '70', '', '', '2014-10-18 07:55:34', '2014-10-18 07:55:34', '', 0, 'http://192.168.1.77/imagereality/?p=70', 4, 'nav_menu_item', '', 0),
(71, 1, '2014-10-18 08:05:24', '2014-10-18 08:05:24', '<p>Your Name (required)<br />\r\n    [text* your-name] </p>\r\n\r\n<p>Your Email (required)<br />\r\n    [email* your-email] </p>\r\n\r\n<p>Subject<br />\r\n    [text your-subject] </p>\r\n\r\n<p>select category<br/>\r\n[select* menu-534 "Query" "Suggestion" "Feedback"]</p>\r\n\r\n<p>Your Message<br />\r\n    [textarea your-message] </p>\r\n\r\n\r\n\r\n<p>[submit "Send"]</p>\n[your-subject]\n[your-name] <[your-email]>\nFrom: [your-name] <[your-email]>\r\nSubject: [your-subject]\r\n\r\nSelected Category: [menu-534]\r\n\r\nMessage Body:\r\n[your-message]\r\n\r\n\r\n--\r\nThis e-mail was sent from a contact form on imagereality (http://192.168.1.77/imagereality)\npoonam@amarinfotech.com\n\n\n\n\n\n[your-subject]\n[your-name] <[your-email]>\nMessage Body:\r\n[your-message]\r\n\r\n--\r\nThis e-mail was sent from a contact form on imagereality (http://192.168.1.77/imagereality)\n[your-email]\n\n\n\n\nYour message was sent successfully. Thanks.\nFailed to send your message. Please try later or contact the administrator by another method.\nValidation errors occurred. Please confirm the fields and submit it again.\nFailed to send your message. Please try later or contact the administrator by another method.\nPlease accept the terms to proceed.\nPlease fill the required field.\nYour entered code is incorrect.\nNumber format seems invalid.\nThis number is too small.\nThis number is too large.\nEmail address seems invalid.\nURL seems invalid.\nTelephone number seems invalid.\nYour answer is not correct.\nDate format seems invalid.\nThis date is too early.\nThis date is too late.\nFailed to upload file.\nThis file type is not allowed.\nThis file is too large.\nFailed to upload file. Error occurred.', 'Reach_us', '', 'publish', 'open', 'open', '', 'reach_us', '', '', '2014-10-18 08:10:24', '2014-10-18 08:10:24', '', 0, 'http://192.168.1.77/imagereality/?post_type=wpcf7_contact_form&#038;p=71', 0, 'wpcf7_contact_form', '', 0),
(72, 1, '2014-10-18 08:22:42', '2014-10-18 08:22:42', '', 'registration', '', 'publish', 'open', 'open', '', 'registration', '', '', '2014-10-18 08:22:42', '2014-10-18 08:22:42', '', 0, 'http://192.168.1.77/imagereality/?page_id=72', 0, 'page', '', 0),
(73, 1, '2014-10-18 08:22:42', '2014-10-18 08:22:42', '', 'registration', '', 'inherit', 'open', 'open', '', '72-revision-v1', '', '', '2014-10-18 08:22:42', '2014-10-18 08:22:42', '', 72, 'http://192.168.1.77/imagereality/?p=73', 0, 'revision', '', 0),
(74, 1, '2014-10-18 09:07:16', '2014-10-18 09:07:16', 'At compile time, when the code does not comply with the Java syntactic and semantics rules as described in Java Language Specification (JLS), compile-time errors will occurs. The goal of the compiler is to ensure the code is compliant with these rules. Any rule-violations detected at this stage are reported as compilation errors.\r\n\r\nThe best way to get to know those rules is to go through all the sections in the JLS containing the key words “compile-time error”. In general, these rules include syntax checking: declarations, expressions, lexical parsing, file-naming conventions etc; exception handling: for checked exceptions; accessibility, type-compatibility, name resolution: checking to see all named entities – variables, classes, method calls etc. are reachable through at least one of the declared path; etc.', 'QA1', '', 'publish', 'open', 'open', '', 'qa1', '', '', '2014-10-18 09:07:16', '2014-10-18 09:07:16', '', 0, 'http://192.168.1.77/imagereality/?post_type=q-a&#038;p=74', 0, 'q-a', '', 0),
(75, 1, '2014-10-18 09:07:46', '2014-10-18 09:07:46', 'At compile time, when the code does not comply with the Java syntactic and semantics rules as described in Java Language Specification (JLS), compile-time errors will occurs. The goal of the compiler is to ensure the code is compliant with these rules. Any rule-violations detected at this stage are reported as compilation errors. The best way to get to know those rules is to go through all the sections in the JLS containing the key words “compile-time error”. In general, these rules include syntax checking: declarations, expressions, lexical parsing, file-naming conventions etc; exception handling: for checked exceptions; accessibility, type-compatibility, name resolution: checking to see all named entities – variables, classes, method calls etc. are reachable through at least one of the declareAt compile time, when the code does not comply with the Java syntactic and semantics rules as described in Java Language Specification (JLS), compile-time errors will occurs. The goal of the compiler is to ensure the code is compliant with these rules. Any rule-violations detected at this stage are reported as compilation errors. The best way to get to know those rules is to go through all the sections in the JLS containing the key words “compile-time error”. In general, these rules include syntax checking: declarations, expressions, lexical parsing, file-naming conventions etc; exception handling: for checked exceptions; accessibility, type-compatibility, name resolution: checking to see all named entities – variables, classes, method calls etc. are reachable through at least one of the declared path; etc.d path; etc.', 'QA2', '', 'publish', 'open', 'open', '', 'qa2', '', '', '2014-10-18 09:07:46', '2014-10-18 09:07:46', '', 0, 'http://192.168.1.77/imagereality/?post_type=q-a&#038;p=75', 0, 'q-a', '', 0),
(76, 1, '2014-10-18 09:09:55', '2014-10-18 09:09:55', 'DEVELOPER\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\r\n\r\nSELL\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'A1', '', 'publish', 'open', 'open', '', 'a1', '', '', '2014-10-18 09:09:55', '2014-10-18 09:09:55', '', 0, 'http://192.168.1.77/imagereality/?post_type=announcements&#038;p=76', 0, 'announcements', '', 0),
(77, 1, '2014-10-18 09:10:17', '2014-10-18 09:10:17', 'DEVELOPER\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\r\n\r\nSELL\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'A2', '', 'publish', 'open', 'open', '', 'a2', '', '', '2014-10-18 09:10:17', '2014-10-18 09:10:17', '', 0, 'http://192.168.1.77/imagereality/?post_type=announcements&#038;p=77', 0, 'announcements', '', 0),
(78, 1, '2014-10-18 09:10:49', '2014-10-18 09:10:49', 'DEVELOPER\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\r\n\r\nSELL\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'N1', '', 'publish', 'open', 'open', '', 'n1', '', '', '2014-10-18 09:10:49', '2014-10-18 09:10:49', '', 0, 'http://192.168.1.77/imagereality/?post_type=news&#038;p=78', 0, 'news', '', 0),
(79, 1, '2014-10-18 09:10:59', '2014-10-18 09:10:59', 'DEVELOPER\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\r\n\r\nSELL\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'N2', '', 'publish', 'open', 'open', '', 'n2', '', '', '2014-10-18 09:10:59', '2014-10-18 09:10:59', '', 0, 'http://192.168.1.77/imagereality/?post_type=news&#038;p=79', 0, 'news', '', 0),
(80, 1, '2014-10-18 10:07:15', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-10-18 10:07:15', '0000-00-00 00:00:00', '', 0, 'http://192.168.1.77/imagereality/?p=80', 0, 'post', '', 0),
(81, 1, '2014-10-18 10:07:26', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-10-18 10:07:26', '0000-00-00 00:00:00', '', 0, 'http://192.168.1.77/imagereality/?p=81', 0, 'post', '', 0),
(82, 1, '2014-10-18 10:07:35', '2014-10-18 10:07:35', '', 'background', '', 'inherit', 'open', 'open', '', 'background', '', '', '2014-10-18 10:07:35', '2014-10-18 10:07:35', '', 81, 'http://192.168.1.77/imagereality/wp-content/uploads/2014/10/background.jpg', 0, 'attachment', 'image/jpeg', 0),
(83, 1, '2014-10-18 10:29:07', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-10-18 10:29:07', '0000-00-00 00:00:00', '', 0, 'http://192.168.1.77/imagereality/?page_id=83', 0, 'page', '', 0),
(84, 1, '2014-10-18 10:31:01', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-10-18 10:31:01', '0000-00-00 00:00:00', '', 0, 'http://192.168.1.77/imagereality/?page_id=84', 0, 'page', '', 0),
(85, 1, '2014-10-18 12:53:26', '2014-10-18 12:53:26', '', 'Developer1', '', 'publish', 'open', 'open', '', 'developer1', '', '', '2014-10-18 12:53:26', '2014-10-18 12:53:26', '', 0, 'http://192.168.1.77/imagereality/?page_id=85', 0, 'page', '', 0),
(86, 1, '2014-10-18 12:53:26', '2014-10-18 12:53:26', '', 'Developer1', '', 'inherit', 'open', 'open', '', '85-revision-v1', '', '', '2014-10-18 12:53:26', '2014-10-18 12:53:26', '', 85, 'http://192.168.1.77/imagereality/?p=86', 0, 'revision', '', 0),
(87, 1, '2014-10-18 12:53:39', '2014-10-18 12:53:39', '', 'Developer2', '', 'publish', 'open', 'open', '', 'developer2', '', '', '2014-10-18 12:53:39', '2014-10-18 12:53:39', '', 0, 'http://192.168.1.77/imagereality/?page_id=87', 0, 'page', '', 0),
(88, 1, '2014-10-18 12:53:49', '2014-10-18 12:53:49', '', 'Developer3', '', 'publish', 'open', 'open', '', 'developer3', '', '', '2014-10-18 12:53:49', '2014-10-18 12:53:49', '', 0, 'http://192.168.1.77/imagereality/?page_id=88', 0, 'page', '', 0),
(89, 1, '2014-10-18 12:53:39', '2014-10-18 12:53:39', '', 'Developer2', '', 'inherit', 'open', 'open', '', '87-revision-v1', '', '', '2014-10-18 12:53:39', '2014-10-18 12:53:39', '', 87, 'http://192.168.1.77/imagereality/?p=89', 0, 'revision', '', 0),
(90, 1, '2014-10-18 12:53:49', '2014-10-18 12:53:49', '', 'Developer3', '', 'inherit', 'open', 'open', '', '88-revision-v1', '', '', '2014-10-18 12:53:49', '2014-10-18 12:53:49', '', 88, 'http://192.168.1.77/imagereality/?p=90', 0, 'revision', '', 0),
(91, 1, '2014-10-18 12:54:07', '2014-10-18 12:54:07', '', 'Developer4', '', 'publish', 'open', 'open', '', 'developer4', '', '', '2014-10-18 12:54:07', '2014-10-18 12:54:07', '', 0, 'http://192.168.1.77/imagereality/?page_id=91', 0, 'page', '', 0),
(92, 1, '2014-10-18 12:54:07', '2014-10-18 12:54:07', '', 'Developer4', '', 'inherit', 'open', 'open', '', '91-revision-v1', '', '', '2014-10-18 12:54:07', '2014-10-18 12:54:07', '', 91, 'http://192.168.1.77/imagereality/?p=92', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE IF NOT EXISTS `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Announcements', 'announcements', 0),
(3, 'News', 'news', 0),
(4, 'Q &amp; A', 'q-a', 0),
(5, 'menu', 'menu', 0),
(6, 'footer_right', 'footer_right', 0),
(7, 'header_right', 'header_right', 0),
(8, 'social_footer', 'social_footer', 0),
(9, 'Cities', 'cities', 0),
(10, 'NEW CAIRO', 'new-cairo', 0),
(11, 'AL AIN AL SOKHNA', 'al-ain-al-sokhna', 0),
(12, 'AL SHOROUK CITY', 'al-shorouk-city', 0),
(13, 'RED SEA', 'red-sea', 0),
(14, '6TH OF OCTOBER', '6th-of-october', 0),
(15, 'NORTH COAST', 'north-coast', 0),
(16, 'SHOW ALL', 'show-all', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE IF NOT EXISTS `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(45, 5, 0),
(46, 5, 0),
(48, 5, 0),
(49, 6, 0),
(50, 6, 0),
(51, 6, 0),
(52, 6, 0),
(53, 6, 0),
(54, 6, 0),
(55, 6, 0),
(56, 6, 0),
(59, 7, 0),
(60, 7, 0),
(61, 8, 0),
(62, 8, 0),
(63, 8, 0),
(64, 8, 0),
(65, 8, 0),
(66, 8, 0),
(68, 5, 0),
(69, 5, 0),
(70, 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE IF NOT EXISTS `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'category', '', 0, 0),
(3, 3, 'category', '', 0, 0),
(4, 4, 'category', '', 0, 0),
(5, 5, 'nav_menu', '', 0, 6),
(6, 6, 'nav_menu', '', 0, 8),
(7, 7, 'nav_menu', '', 0, 2),
(8, 8, 'nav_menu', '', 0, 6),
(9, 9, 'category', '', 0, 0),
(10, 10, 'category', '', 9, 0),
(11, 11, 'category', '', 9, 0),
(12, 12, 'category', '', 9, 0),
(13, 13, 'category', '', 9, 0),
(14, 14, 'category', '', 9, 0),
(15, 15, 'category', '', 9, 0),
(16, 16, 'category', '', 9, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_useful_banner_manager_banners`
--

CREATE TABLE IF NOT EXISTS `wp_useful_banner_manager_banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `banner_name` varchar(255) NOT NULL,
  `banner_type` varchar(4) NOT NULL,
  `banner_title` varchar(255) NOT NULL,
  `banner_alt` text NOT NULL,
  `banner_link` varchar(255) NOT NULL,
  `link_target` varchar(7) NOT NULL,
  `link_rel` varchar(8) NOT NULL,
  `banner_width` int(11) NOT NULL,
  `banner_height` int(11) NOT NULL,
  `added_date` varchar(10) NOT NULL,
  `active_until` varchar(10) NOT NULL,
  `banner_order` int(11) NOT NULL DEFAULT '0',
  `wrapper_id` varchar(255) NOT NULL,
  `wrapper_class` varchar(255) NOT NULL,
  `is_visible` varchar(3) NOT NULL,
  `banner_added_by` varchar(50) NOT NULL,
  `banner_edited_by` text NOT NULL,
  `last_edited_date` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `wp_useful_banner_manager_banners`
--

INSERT INTO `wp_useful_banner_manager_banners` (`id`, `banner_name`, `banner_type`, `banner_title`, `banner_alt`, `banner_link`, `link_target`, `link_rel`, `banner_width`, `banner_height`, `added_date`, `active_until`, `banner_order`, `wrapper_id`, `wrapper_class`, `is_visible`, `banner_added_by`, `banner_edited_by`, `last_edited_date`) VALUES
(3, 'background', 'jpg', 'img_233X115', '', '', '', '', 233, 115, '2014-10-18', '-1', 0, '', '', 'yes', 'admin', '', ''),
(4, 'background_1', 'jpg', 'img1_233X115', '', '', '', '', 233, 115, '2014-10-18', '-1', 0, '', '', 'yes', 'admin', '', ''),
(5, 'background_2', 'jpg', 'img_233X223', '', '', '', '', 233, 223, '2014-10-18', '-1', 0, '', '', 'yes', 'admin', '', ''),
(6, 'background_3', 'jpg', 'img1_233X223', '', '', '', '', 233, 223, '2014-10-18', '-1', 0, '', '', 'yes', 'admin', '', ''),
(7, 'background_4', 'jpg', 'img1_233X75', '', '', '', '', 233, 75, '2014-10-18', '-1', 0, '', '', 'yes', 'admin', '', ''),
(8, 'background', 'jpg', 'img_233X75', '', '', '', '', 233, 75, '2014-10-18', '-1', 0, '', '', 'yes', 'admin', '', ''),
(9, 'background', 'jpg', 'img1_900X105', '', '', '', '', 900, 105, '2014-10-18', '-1', 0, '', '', 'yes', 'admin', '', ''),
(10, 'we_3', 'jpg', 'img_900X105', '', '', '', '', 900, 105, '2014-10-18', '-1', 0, '', '', 'yes', 'admin', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE IF NOT EXISTS `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'wp_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', 'wp350_media,wp360_revisions,wp360_locks,wp390_widgets'),
(13, 1, 'show_welcome_panel', '1'),
(15, 1, 'wp_dashboard_quick_press_last_post_id', '3'),
(16, 1, 'managenav-menuscolumnshidden', 'a:3:{i:0;s:11:"link-target";i:1;s:3:"xfn";i:2;s:11:"description";}'),
(17, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}'),
(18, 1, 'wp_user-settings', 'editor=html'),
(19, 1, 'wp_user-settings-time', '1413614006'),
(20, 1, 'closedpostboxes_page', 'a:0:{}'),
(21, 1, 'metaboxhidden_page', 'a:6:{i:0;s:12:"revisionsdiv";i:1;s:11:"postexcerpt";i:2;s:16:"commentstatusdiv";i:3;s:11:"commentsdiv";i:4;s:7:"slugdiv";i:5;s:9:"authordiv";}'),
(22, 1, 'nav_menu_recently_edited', '6'),
(28, 2, 'nickname', 'pooja'),
(29, 2, 'first_name', 'pooja'),
(30, 2, 'last_name', 'mule'),
(31, 2, 'description', ''),
(32, 2, 'rich_editing', 'true'),
(33, 2, 'comment_shortcuts', 'false'),
(34, 2, 'admin_color', 'fresh'),
(35, 2, 'use_ssl', '0'),
(36, 2, 'show_admin_bar_front', 'true'),
(37, 2, 'wp_capabilities', 'a:1:{s:9:"developer";b:1;}'),
(38, 2, 'wp_user_level', '0'),
(39, 2, 'dismissed_wp_pointers', 'wp350_media,wp360_revisions,wp360_locks,wp390_widgets'),
(42, 1, 'session_tokens', 'a:2:{s:64:"71c8f1ddd17091c8555ab75c05248ff3562f76e7d186d0bdefd3c1ebe8011b80";i:1413795155;s:64:"3ab46bf8e869eb068eb63f5493c1ca49d9b6f67c5510c535b8d2e7b3578cfa44";i:1413797352;}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE IF NOT EXISTS `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$Bj7Nk6PVLKlM.LaN1GLTuEssQubF9.1', 'admin', 'poonam@amarinfotech.com', '', '2014-10-18 05:45:38', '', 0, 'admin'),
(2, 'pooja', '$P$BaoDOieswnnpCzS4KfDZRb7o76gkEh0', 'pooja', 'pooja@amarinfotech.com', '', '2014-10-18 08:38:26', '', 0, 'pooja mule');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
